# Deprecated! All files will be moved to new repository.

We decided to move Angular Version to separate repository. You can find all files here: [Angular Version (Angular 2+)](https://github.com/mrholek/CoreUI-Angular)
